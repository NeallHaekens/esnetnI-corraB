<?php $__env->startSection('content'); ?>

    <div class="container">
        <h2 class="yellow">Prijsopgaven maken</h2>

        <form action="<?php echo e(route('quotations.index')); ?>" method="post">

            <div class="form-group">
                <label for="">Klant_id:</label>
                <select name="customer_id" id="customer_id">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option id="customer_id" value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="">Lease_id:</label>
                <select name="lease_id" id="customer_id">
                    <?php $__currentLoopData = $leases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option id="lease_id" value="<?php echo e($lease->id); ?>"><?php echo e($lease->id); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <form action="<?php echo e(route('quotations.index')); ?>" method="post">
                <div class="form-group">
                    <label for="">Product toevoegen</label>
                    <select name="lease_id" id="supply_id">
                        <?php $__currentLoopData = $supplys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option id="supply_id" value="<?php echo e($supply->id); ?>"><?php echo e($supply->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="submit" name="addProductButton" value="Product toevoegen">
                </div>
            </form>


        </form>


    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\esnetnI-corraB\Barroc_Intense\resources\views/sales/create.blade.php ENDPATH**/ ?>