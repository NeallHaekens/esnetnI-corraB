<?php
/**
 * Created by PhpStorm.
 * User: Gebruiker
 * Date: 18-11-2019
 * Time: 13:06
 */?>
<h1>You are now in supplier</h1><?php /**PATH C:\xampp\htdocs\esnetnI-corraB\Barroc_Intense\resources\views/supplier/index.blade.php ENDPATH**/ ?>