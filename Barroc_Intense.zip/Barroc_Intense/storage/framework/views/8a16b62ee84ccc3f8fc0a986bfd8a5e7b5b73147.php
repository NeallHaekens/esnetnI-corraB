<?php $__env->startSection('title'); ?>
    <?php echo e($customer->name); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container">
            <div>
                <h3><?php echo e($customer->name); ?></h3>
                <p>Email: <?php echo e($customer->email); ?> </p>
                <a class="submit-btn" href="<?php echo e(route('customer.edit', Auth::user()->id)); ?>">Gegevens aanpassen<span class="yellow">.</span></a>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\esnetnI-corraB\Barroc_Intense\resources\views/customer/show.blade.php ENDPATH**/ ?>