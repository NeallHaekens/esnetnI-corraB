<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container">
            <h2>Klant<span class="yellow">.</span></h2>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($customer->role_id == 9): ?>
                    <ul class="lists">
                        <li>
                            <a  href="<?php echo e(route('sales.show', $customer->role_id)); ?>"><img class="icons" src="<?php echo e(asset('icons/account_yellow.png')); ?>" alt=""><?php echo e($customer->name); ?></a>
                        </li>
                    </ul>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <section class="content">
        <div class="container">
            <h2>Commentaar<span class="yellow">.</span></h2>
            <a class="submit-btn" href="<?php echo e(asset('notes/create')); ?>">commentaar toevoegen<span class="yellow">.</span></a>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\esnetnI-corraB\Barroc_Intense\resources\views/sales/index.blade.php ENDPATH**/ ?>