<?php $__env->startSection('title'); ?>
    Aantekening maken
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container">
            <form method="POST" action="<?php echo e(route('notes.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <label for="note" class="col-md-4 col-form-label text-md-right">Selecteer een Klant</label>
                    <select name="customer_id" id="customer_id">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option id="customer_id" value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group row">
                    <label for="note" class="col-md-4 col-form-label text-md-right">Notitie</label>
                    <textarea  class="col-md-4 col-form-label text-md-right" name="note" id="note" cols="30" rows=""></textarea>
                </div>

                <div class="form-group row mb-0">
                    <div class="col-md-8 offset-md-4">
                        <input class="submit-btn" type="submit" value="Toevoegen">
                    </div>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\esnetnI-corraB\Barroc_Intense\resources\views/notes/create.blade.php ENDPATH**/ ?>