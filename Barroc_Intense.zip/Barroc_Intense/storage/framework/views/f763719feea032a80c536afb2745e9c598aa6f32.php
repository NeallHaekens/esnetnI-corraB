<?php $__env->startSection('content'); ?>

    <h1>User Create</h1>

    <form action="<?php echo e(route('sales.store')); ?>" method="post">

        <?php echo method_field('PUT'); ?>

        <?php echo csrf_field(); ?>

        <div class="col-md-6">
            <label>Name</label>
            <input type="text" name="name" >
        </div>

        <div class="input-group">
            <label>Email</label>
            <input type="email" name="email" >
        </div>

        <div class="input-group">
            <label>Password</label>
            <input type="password" name="password_1">
        </div>

        <div class="input-group">
            <label>Confirm password</label>
            <input type="password" name="password_2">
        </div>

        <div class="input-group">
            <button type="submit" class="btn" name="reg_user">Register</button>
        </div>

        <p>
            Already a member? <a href="UserLogin.blade.php">Sign in</a>
        </p>

    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\esnetnI-corraB\Barroc_Intense\resources\views/sales/UserCreate.blade.php ENDPATH**/ ?>