<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Edit Company details</h1>
        <form action="<?php echo e(route('Company.update', $company->id)); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="">Company Name</label>
                <input name="CName" type="text" value="<?php echo e($company->company_name); ?>">
            </div>

            <div class="form-group">
                <label for="">Phone</label>
                <input type="text" name="Phone" value="<?php echo e($company->phone_number); ?>">
            </div>
            <div class="form-group">
                <label for="">Email</label>
                <input type="text" name="Email" value="<?php echo e($company->email); ?>">
            </div>
            <div class="form-group">
                <label for="">Adress</label>
                <input type="text" name="Adress" value="<?php echo e($company->adress); ?>">
            </div>
            <div class="form-group">
                <label class="">BKR</label>
                <select class="custom-select-sm" name="bkr">

                    <option value="denied">Denied</option>
                    <option value="accepted">Accepted</option>

                </select>
            </div>

            <input type="submit" value="Edit Product">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\esnetnI-corraB\Barroc_Intense\resources\views/finance/edit.blade.php ENDPATH**/ ?>