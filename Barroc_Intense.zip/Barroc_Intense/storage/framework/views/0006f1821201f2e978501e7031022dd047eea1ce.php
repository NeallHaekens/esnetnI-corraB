<?php $__env->startSection('title'); ?>
    Finance
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container">
            <h2>Finance</h2>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\esnetnI-corraB\Barroc_Intense\resources\views/finance/index.blade.php ENDPATH**/ ?>