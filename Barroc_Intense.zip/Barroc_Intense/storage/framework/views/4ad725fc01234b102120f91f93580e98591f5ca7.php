<?php $__env->startSection('content'); ?>
    <h1>Maak Prijsopgace</h1>

    <form action="" method="post">
        <?php echo csrf_field(); ?>
        .form-group
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\esnetnI-corraB\Barroc_Intense\resources\views/offer/create.blade.php ENDPATH**/ ?>