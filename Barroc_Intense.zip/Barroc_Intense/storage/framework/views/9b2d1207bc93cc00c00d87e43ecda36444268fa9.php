<?php $__env->startSection('content'); ?>

<div class="container">
    <h1>Companys</h1>
        <ul>
            <?php $__currentLoopData = $companys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="Wrapper">

                    <div class="companys">
                        <li class="links"><a href="<?php echo e(route('Company.edit',$company->id)); ?>" class="links-header2"><?php echo e($company->company_name); ?></a></li>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\esnetnI-corraB\Barroc_Intense\resources\views/finance/bkr.blade.php ENDPATH**/ ?>