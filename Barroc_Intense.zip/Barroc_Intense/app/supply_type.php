<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class supply_type extends Model
{
    protected $fillable = ['title'];
}
