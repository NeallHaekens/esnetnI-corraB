<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lease_rule extends Model
{
    public $table = "lease_rules";
}
