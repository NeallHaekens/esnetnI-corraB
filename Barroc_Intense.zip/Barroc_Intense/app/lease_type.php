<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lease_type extends Model
{
    public $table = "lease_type";
}
