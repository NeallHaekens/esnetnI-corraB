<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Malfunction_type extends Model
{
    //
}
