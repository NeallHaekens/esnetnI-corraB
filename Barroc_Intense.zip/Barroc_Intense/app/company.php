<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class company extends Model
{

    public $table = "companydetails";

    protected $fillable = ['BKR'];

}
