@extends('layouts.app')

@section('title', 'Head-Finance')

@section('content')

    <section class="content">
        <div class="container">

        </div>
    </section>

@endsection
