@extends('layouts.app')

@section('title', 'head-off Maintenance')

@section('content')

    <section class="content">
        <div class="container">

        </div>
    </section>

@endsection
