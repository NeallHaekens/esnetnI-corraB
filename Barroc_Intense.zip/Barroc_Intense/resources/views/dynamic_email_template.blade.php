<p>Klant naam : {{ $data['name'] }}</p>
<br>
<p>Onderwerp : {{ $data['topic'] }}</p>
<br>
<p>Beschrijving : {{ $data['beschrijving'] }}</p>