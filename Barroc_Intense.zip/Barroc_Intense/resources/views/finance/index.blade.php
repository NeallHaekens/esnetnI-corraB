@extends('layouts.app')

@section('title')
    Finance
@endsection

@section('content')
    <section class="content">
        <div class="container">
            <h2>Finance</h2>
        </div>
    </section>

@endsection
