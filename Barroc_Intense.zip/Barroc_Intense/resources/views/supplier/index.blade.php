@extends('../layouts.app')

@section('title')
    Supplier
@endsection

@section('content')
    <section class="content">
        <div class="container">

        </div>
    </section>

@endsection
