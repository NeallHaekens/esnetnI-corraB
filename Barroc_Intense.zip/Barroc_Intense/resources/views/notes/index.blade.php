@extends('layouts/app')

@section('title')
    Aantekening maken
@endsection



@section('content')
    <section class="content">
        <div class="container">
           <div>
               <ul>
                   <li>
                       {{}}
                   </li>
               </ul>
           </div>
        </div>
    </section>
@endsection
