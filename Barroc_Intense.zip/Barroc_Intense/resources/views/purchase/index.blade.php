<form method="GET">
    <input type="text" name="name">
    <input type="checkbox" name="hasCoffeeMachine" value="1"><span> Apply Filter</span>
</form>
